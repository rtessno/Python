import pygame

class Card(pygame.sprite.Sprite):
    def __init__(self,img):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((72,96))
        self.image = pygame.image.load(img)
        self.image = self.image.convert_alpha()
        self.rect = self.image.get_rect()
##    def update(self,seconds):
##        self.rect.center = self.pos
    def get_image(self):
        return self.image
