import cardsmod,time,random,pygame, sys
from pygame.locals import *

pygame.init()

# setup the window
screen = pygame.display.set_mode((550,400))
pygame.display.set_caption('Black Jack')
background = pygame.Surface(screen.get_size())
background.fill((255,255,255))
background = background.convert()
screen.blit(background,(0,0))

#load font, prepare values
font = pygame.font.Font(None, 36)
text = 'Black Jack'
size = font.size(text)
ren = font.render(text, 0, (255,255,0), (0,0,255))
screen.blit(ren, (1, 2))

mainloop = True
while mainloop:
    cardnums = set(list(range(1,53)))
    dhand = set()
    d_cards = []
    dtotal = 0

    dn_card = cardsmod.Card('b2fv.png')

    while len(dhand) < 2:
        no = random.choice(list(cardnums))
        dhand.add(no)
        d_cards.append(cardsmod.Card(str(no) + '.png'))
        if no % 13 > 10 or no % 13 == 0:
            dtotal += 10
        elif no % 13 == 1:
            dtotal += 11
        else:
            dtotal += no % 13

    cardnums = cardnums - dhand
    if dtotal == 22:
        dtotal = 12
    #print(dtotal)
    ### show dealer's hand
    screen.blit(dn_card.get_image(),(80,40))
    screen.blit(d_cards[0].get_image(),(160,40))

    phand = set()
    p_cards = []
    ptotal = 0

    while len(phand) < 2:
        no = random.choice(list(cardnums))
        phand.add(no)
    for no in phand:
        p_cards.append(cardsmod.Card(str(no) + '.png'))
        if no % 13 >= 10 or no % 13 == 0:
            ptotal += 10
        elif no % 13 == 1:
            ptotal += 11
        else:
            ptotal += no % 13

    cardnums = cardnums -phand
    if ptotal == 22:
        ptotal = 12
    #print(ptotal)
    ### show player's hand
    screen.blit(p_cards[0].get_image(),(80,180))
    screen.blit(p_cards[1].get_image(),(160,180))

    total = '  Total: ' + str(ptotal) + '   '
    if ptotal == 21:
        total += ' Black Jack! You win!'
    tot = font.render(total, 0, (255,255,0), (0,0,255))
    screen.blit(tot, (80, 300))

    print(cardnums)
    pygame.display.update()
    time.sleep(5)
    tot2 = font.render(total, 0, (255,255,255), (255,255,255))
    screen.blit(tot2, (80, 300))
    
    for event in pygame.event.get():
        # User presses QUIT-button.
        if event.type == pygame.QUIT:
            mainloop = False 
        elif event.type == pygame.KEYDOWN:
            # User presses ESCAPE-Key
            if event.key == pygame.K_ESCAPE:
                mainloop = False
            
pygame.quit()





        
