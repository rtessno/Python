# button_label.py   demonstrates a Button widget that sets a label's text

import tkinter

class MyGUI:
    def __init__(self):
        # Create the main window widget.
        self.main_window = tkinter.Tk()

        # Create a Button widget. hello method runs when the user clicks the Button.
        self.butt = tkinter.Button(self.main_window,text='Say Hello',command=self.hello)

        # Create a StringVar instance and associate with label
        self.label_txt = tkinter.StringVar()
        # Create a Label widget that will have its text set by the hello method
        self.output = tkinter.Label(self.main_window,textvariable=self.label_txt)

        # Pack the Button and the Label
        self.butt.pack()
        self.output.pack()
        
        # Enter the tkinter main loop.
        tkinter.mainloop()

    # The hello method is a callback function for the Button.
    def hello(self):
        self.label_txt.set('Hello, world')      ## note use of set() method

# Create an instance of the MyGUI class.
my_gui = MyGUI()

