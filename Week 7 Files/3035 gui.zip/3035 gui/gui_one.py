#### gui_one.py

import tkinter

class ThisGUI:
    def __init__(self):
        self.main_window = tkinter.Tk()
        
        # make two frames to enclose other widgets
        self.upper_frame = tkinter.Frame(self.main_window)
        self.lower_frame = tkinter.Frame(self.main_window)

        # make a label widget and entry widget for upper frame
        self.label_one = tkinter.Label(self.upper_frame,text='Enter Name')
        self.entry_name = tkinter.Entry(self.upper_frame,width=15)
        # pack upper frame's widgets into place
        self.label_one.pack(side='left')
        self.entry_name.pack(side='right')

        self.button_1 = tkinter.Button(self.lower_frame,text='Process',command=self.do_it)

        # create StringVar object, then associate StringVar object with next label
        self.out_str = tkinter.StringVar()
        self.label_out = tkinter.Label(self.lower_frame,textvariable=self.out_str)
        
        self.button_1.pack(side='top')
        self.label_out.pack(side='top')

        self.upper_frame.pack()
        self.lower_frame.pack()

        tkinter.mainloop()

    def do_it(self):
            # retrieve user name from the Entry widget
            user = self.entry_name.get()
            self.out_str.set('Hello, ' + user)
            print('Hello', user)
            
            

def main():
    tg = ThisGUI()

main()
