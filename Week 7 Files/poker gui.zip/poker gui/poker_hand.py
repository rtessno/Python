### pokerhand.py

import tkinter, random
from PIL import Image,ImageTk

root = tkinter.Tk()

hand = tkinter.Frame(root)

cards = []
for c in range(5):
    cards.append(str(random.randint(1,52)) + '.png')
    
img0 = Image.open(cards[0])
pix0 = ImageTk.PhotoImage(img0)
card0 = tkinter.Label(hand,image=pix0)

img1 = Image.open(cards[1])
pix1 = ImageTk.PhotoImage(img1)
card1 = tkinter.Label(hand,image=pix1)

img2 = Image.open(cards[2])
pix2 = ImageTk.PhotoImage(img2)
card2 = tkinter.Label(hand,image=pix2)

img3 = Image.open(cards[3])
pix3 = ImageTk.PhotoImage(img3)
card3 = tkinter.Label(hand,image=pix3)

img4 = Image.open(cards[4])
pix4 = ImageTk.PhotoImage(img4)
card4 = tkinter.Label(hand,image=pix4)

card0.pack(side='left')
card1.pack(side='left')
card2.pack(side='left')
card3.pack(side='left')
card4.pack(side='left')

hand.pack()
root.title('Poker Hand')        
                                                                      
root.mainloop()

